#!/usr/bin/env python3
"""
Setup script for Titanic Streamlit App
======================================

This script helps set up the environment for running the Titanic
Streamlit application.
"""

import subprocess
import sys
import os
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible."""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required.")
        print(f"   Current version: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version.split()[0]}")
    return True

def install_requirements():
    """Install required packages from requirements.txt."""
    print("\n📦 Installing required packages...")
    
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ All packages installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing packages: {e}")
        return False
    except FileNotFoundError:
        print("❌ requirements.txt not found. Please ensure you're in the correct directory.")
        return False

def check_dataset():
    """Check if the Titanic dataset is available."""
    print("\n📊 Checking for Titanic dataset...")
    
    possible_paths = ["titanic.csv", "data/titanic.csv", "datasets/titanic.csv", "train.csv"]
    
    for path in possible_paths:
        if os.path.exists(path):
            print(f"✅ Dataset found at: {path}")
            return True
    
    print("❌ Titanic dataset not found!")
    print("\n📥 To download the dataset:")
    print("1. Go to: https://www.kaggle.com/c/titanic/data")
    print("2. Download 'train.csv'")
    print("3. Place it in the same directory as this script")
    print("4. Rename it to 'titanic.csv'")
    return False

def run_tests():
    """Run the test suite to verify functionality."""
    print("\n🧪 Running tests...")
    
    try:
        result = subprocess.run([sys.executable, "test_app.py"], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ All tests passed!")
            return True
        else:
            print("❌ Some tests failed:")
            print(result.stdout)
            print(result.stderr)
            return False
            
    except FileNotFoundError:
        print("❌ test_app.py not found. Skipping tests.")
        return False

def main():
    """Main setup function."""
    print("🚀 Titanic Streamlit App Setup")
    print("=" * 40)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Install requirements
    if not install_requirements():
        print("\n💡 Try installing packages manually:")
        print("   pip install -r requirements.txt")
        sys.exit(1)
    
    # Check dataset
    dataset_available = check_dataset()
    
    # Run tests
    tests_passed = run_tests()
    
    # Summary
    print("\n" + "=" * 40)
    print("📋 Setup Summary:")
    print(f"   Python version: ✅ Compatible")
    print(f"   Dependencies: ✅ Installed")
    print(f"   Dataset: {'✅ Available' if dataset_available else '❌ Missing'}")
    print(f"   Tests: {'✅ Passed' if tests_passed else '❌ Failed'}")
    
    if dataset_available and tests_passed:
        print("\n🎉 Setup complete! You can now run the app:")
        print("   streamlit run app.py")
    else:
        print("\n⚠️  Setup incomplete. Please address the issues above.")
        if not dataset_available:
            print("   - Download the Titanic dataset from Kaggle")
        if not tests_passed:
            print("   - Check the test output for errors")
    
    return dataset_available and tests_passed

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
