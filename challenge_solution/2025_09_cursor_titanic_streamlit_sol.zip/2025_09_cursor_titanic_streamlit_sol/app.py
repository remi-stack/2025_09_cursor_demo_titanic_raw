"""
Titanic Dataset Explorer - Streamlit App
=========================================

This app loads and explores the Titanic dataset from Kaggle, providing
interactive visualizations and key statistics.

Data source: Kaggle Titanic dataset
Features: Survival analysis, passenger demographics, fare analysis
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Dict, List, Optional, Tuple
import warnings

# Configure warnings and styling
warnings.filterwarnings('ignore')
sns.set_style("whitegrid")
plt.style.use('seaborn-v0_8')

# Page configuration
st.set_page_config(
    page_title="Titanic Dataset Explorer",
    page_icon="🚢",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Color palette for consistent styling
COLORS = {
    'primary': '#1f77b4',
    'secondary': '#ff7f0e',
    'success': '#2ca02c',
    'danger': '#d62728',
    'warning': '#ff7f0e',
    'info': '#17a2b8',
    'light': '#f8f9fa',
    'dark': '#343a40'
}

@st.cache_data
def load_titanic_data() -> pd.DataFrame:
    """
    Load Titanic dataset with error handling and caching.
    
    Returns:
        pd.DataFrame: Loaded Titanic dataset
        
    Raises:
        FileNotFoundError: If dataset file is not found
        Exception: For other data loading errors
    """
    try:
        # Try to load from common Kaggle dataset paths
        possible_paths = [
            "titanic.csv",
            "data/titanic.csv",
            "datasets/titanic.csv",
            "train.csv"
        ]
        
        df = None
        for path in possible_paths:
            try:
                df = pd.read_csv(path)
                st.success(f"✅ Dataset loaded successfully from: {path}")
                break
            except FileNotFoundError:
                continue
        
        if df is None:
            # If no local file found, provide instructions
            st.error("❌ Titanic dataset not found locally!")
            st.info("""
            **To use this app, please download the Titanic dataset from Kaggle:**
            1. Go to: https://www.kaggle.com/c/titanic/data
            2. Download `train.csv` 
            3. Place it in the same directory as this app
            4. Rename it to `titanic.csv` or update the path in the code
            """)
            st.stop()
            
        return df
        
    except Exception as e:
        st.error(f"❌ Error loading dataset: {str(e)}")
        st.stop()

def preprocess_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess the Titanic dataset for analysis.
    
    Args:
        df (pd.DataFrame): Raw Titanic dataset
        
    Returns:
        pd.DataFrame: Preprocessed dataset
    """
    # Create a copy to avoid modifying original
    df_processed = df.copy()
    
    # Handle missing values
    df_processed['Age'] = df_processed['Age'].fillna(df_processed['Age'].median())
    df_processed['Embarked'] = df_processed['Embarked'].fillna(df_processed['Embarked'].mode()[0])
    df_processed['Fare'] = df_processed['Fare'].fillna(df_processed['Fare'].median())
    
    # Create derived features
    df_processed['Title'] = df_processed['Name'].str.extract(r' ([A-Za-z]+)\.', expand=False)
    df_processed['FamilySize'] = df_processed['SibSp'] + df_processed['Parch'] + 1
    df_processed['IsAlone'] = (df_processed['FamilySize'] == 1).astype(int)
    
    # Convert categorical variables
    df_processed['Sex'] = df_processed['Sex'].astype('category')
    df_processed['Pclass'] = df_processed['Pclass'].astype('category')
    df_processed['Embarked'] = df_processed['Embarked'].astype('category')
    
    return df_processed

def get_basic_info(df: pd.DataFrame) -> Dict:
    """
    Get basic information about the dataset.
    
    Args:
        df (pd.DataFrame): Dataset to analyze
        
    Returns:
        Dict: Basic dataset information
    """
    info = {
        'shape': df.shape,
        'dtypes': df.dtypes,
        'missing_values': df.isnull().sum(),
        'memory_usage': df.memory_usage(deep=True).sum(),
        'numeric_columns': df.select_dtypes(include=[np.number]).columns.tolist(),
        'categorical_columns': df.select_dtypes(include=['category', 'object']).columns.tolist()
    }
    return info

def plot_survival_by_sex(df: pd.DataFrame) -> go.Figure:
    """
    Create a bar chart showing survival rates by gender.
    
    Args:
        df (pd.DataFrame): Preprocessed dataset
        
    Returns:
        go.Figure: Plotly figure object
    """
    survival_by_sex = df.groupby(['Sex', 'Survived']).size().unstack(fill_value=0)
    survival_by_sex['Survival_Rate'] = (survival_by_sex[1] / (survival_by_sex[0] + survival_by_sex[1]) * 100).round(1)
    
    fig = go.Figure()
    
    # Add bars for each gender and survival status
    for sex in ['male', 'female']:
        fig.add_trace(go.Bar(
            name=f'{sex.capitalize()} - Died',
            x=[sex.capitalize()],
            y=[survival_by_sex.loc[sex, 0]],
            marker_color=COLORS['danger'],
            showlegend=True
        ))
        
        fig.add_trace(go.Bar(
            name=f'{sex.capitalize()} - Survived',
            x=[sex.capitalize()],
            y=[survival_by_sex.loc[sex, 1]],
            marker_color=COLORS['success'],
            showlegend=True
        ))
    
    fig.update_layout(
        title="Survival Rates by Gender",
        xaxis_title="Gender",
        yaxis_title="Number of Passengers",
        barmode='stack',
        height=400,
        showlegend=True,
        plot_bgcolor='white'
    )
    
    # Add survival rate annotations
    for i, sex in enumerate(['male', 'female']):
        survival_rate = survival_by_sex.loc[sex, 'Survival_Rate']
        fig.add_annotation(
            x=sex.capitalize(),
            y=survival_by_sex.loc[sex, 0] + survival_by_sex.loc[sex, 1] + 10,
            text=f"Survival Rate: {survival_rate}%",
            showarrow=False,
            font=dict(size=12, color=COLORS['dark'])
        )
    
    return fig

def plot_age_distribution(df: pd.DataFrame, filter_params: Dict) -> go.Figure:
    """
    Create a histogram showing age distribution with optional survival filtering.
    
    Args:
        df (pd.DataFrame): Preprocessed dataset
        filter_params (Dict): Filter parameters from widgets
        
    Returns:
        go.Figure: Plotly figure object
    """
    # Apply filters
    filtered_df = apply_filters(df, filter_params)
    
    fig = go.Figure()
    
    # Create histogram for all passengers
    fig.add_trace(go.Histogram(
        x=filtered_df['Age'],
        nbinsx=20,
        name='All Passengers',
        marker_color=COLORS['primary'],
        opacity=0.7
    ))
    
    # Add survival overlay if not filtered by survival
    if filter_params.get('survival_filter') == 'All':
        survived = filtered_df[filtered_df['Survived'] == 1]['Age']
        died = filtered_df[filtered_df['Survived'] == 0]['Age']
        
        fig.add_trace(go.Histogram(
            x=survived,
            nbinsx=20,
            name='Survived',
            marker_color=COLORS['success'],
            opacity=0.8
        ))
        
        fig.add_trace(go.Histogram(
            x=died,
            nbinsx=20,
            name='Died',
            marker_color=COLORS['danger'],
            opacity=0.8
        ))
    
    fig.update_layout(
        title="Age Distribution of Passengers",
        xaxis_title="Age (years)",
        yaxis_title="Number of Passengers",
        height=400,
        barmode='overlay',
        plot_bgcolor='white',
        showlegend=True
    )
    
    return fig

def plot_numeric_correlations(df: pd.DataFrame) -> go.Figure:
    """
    Create a correlation heatmap for numeric features.
    
    Args:
        df (pd.DataFrame): Preprocessed dataset
        
    Returns:
        go.Figure: Plotly figure object
    """
    # Select numeric columns
    numeric_cols = ['Age', 'Fare', 'SibSp', 'Parch', 'FamilySize', 'Survived']
    numeric_df = df[numeric_cols].copy()
    
    # Calculate correlation matrix
    corr_matrix = numeric_df.corr()
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=corr_matrix.values,
        x=corr_matrix.columns,
        y=corr_matrix.columns,
        colorscale='RdBu',
        zmid=0,
        text=corr_matrix.round(2).values,
        texttemplate="%{text}",
        textfont={"size": 10},
        hoverongaps=False
    ))
    
    fig.update_layout(
        title="Correlation Heatmap of Numeric Features",
        height=500,
        plot_bgcolor='white',
        xaxis_title="Features",
        yaxis_title="Features"
    )
    
    return fig

def apply_filters(df: pd.DataFrame, filter_params: Dict) -> pd.DataFrame:
    """
    Apply filters to the dataset based on widget selections.
    
    Args:
        df (pd.DataFrame): Original dataset
        filter_params (Dict): Filter parameters from widgets
        
    Returns:
        pd.DataFrame: Filtered dataset
    """
    filtered_df = df.copy()
    
    # Apply passenger class filter
    if filter_params.get('pclass_filter') and filter_params['pclass_filter'] != 'All':
        filtered_df = filtered_df[filtered_df['Pclass'] == int(filter_params['pclass_filter'])]
    
    # Apply gender filter
    if filter_params.get('sex_filter') and filter_params['sex_filter'] != 'All':
        filtered_df = filtered_df[filtered_df['Sex'] == filter_params['sex_filter']]
    
    # Apply embarkation port filter
    if filter_params.get('embarked_filter') and filter_params['embarked_filter'] != 'All':
        filtered_df = filtered_df[filtered_df['Embarked'] == filter_params['embarked_filter']]
    
    # Apply survival filter
    if filter_params.get('survival_filter') and filter_params['survival_filter'] != 'All':
        survival_value = 1 if filter_params['survival_filter'] == 'Survived' else 0
        filtered_df = filtered_df[filtered_df['Survived'] == survival_value]
    
    # Apply age range filter
    if filter_params.get('age_range'):
        min_age, max_age = filter_params['age_range']
        filtered_df = filtered_df[(filtered_df['Age'] >= min_age) & (filtered_df['Age'] <= max_age)]
    
    return filtered_df

def display_statistics(df: pd.DataFrame, filtered_df: pd.DataFrame) -> None:
    """
    Display comprehensive statistics for the dataset.
    
    Args:
        df (pd.DataFrame): Original dataset
        filtered_df (pd.DataFrame): Filtered dataset
    """
    st.subheader("📊 Dataset Statistics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("Total Passengers", len(df))
        st.metric("Survival Rate", f"{(df['Survived'].mean() * 100):.1f}%")
        st.metric("Average Age", f"{df['Age'].mean():.1f} years")
        st.metric("Average Fare", f"${df['Fare'].mean():.2f}")
    
    with col2:
        st.metric("Filtered Passengers", len(filtered_df))
        if len(filtered_df) > 0:
            st.metric("Filtered Survival Rate", f"{(filtered_df['Survived'].mean() * 100):.1f}%")
            st.metric("Filtered Avg Age", f"{filtered_df['Age'].mean():.1f} years")
            st.metric("Filtered Avg Fare", f"${filtered_df['Fare'].mean():.2f}")
        else:
            st.metric("Filtered Survival Rate", "N/A")
            st.metric("Filtered Avg Age", "N/A")
            st.metric("Filtered Avg Fare", "N/A")
    
    # Detailed statistics table
    st.subheader("📈 Detailed Statistics")
    
    numeric_cols = ['Age', 'Fare', 'SibSp', 'Parch', 'FamilySize']
    stats_df = filtered_df[numeric_cols].describe()
    
    # Format the statistics
    stats_df = stats_df.round(2)
    stats_df.index = ['Count', 'Mean', 'Std', 'Min', '25%', '50%', '75%', 'Max']
    
    st.dataframe(stats_df, use_container_width=True)

def create_sidebar_filters() -> Dict:
    """
    Create sidebar filters for the dashboard.
    
    Returns:
        Dict: Filter parameters
    """
    st.sidebar.header("🔍 Filters")
    
    # Passenger class filter
    pclass_filter = st.sidebar.selectbox(
        "Passenger Class",
        ['All', '1', '2', '3'],
        help="Filter by passenger class (1st, 2nd, or 3rd class)"
    )
    
    # Gender filter
    sex_filter = st.sidebar.selectbox(
        "Gender",
        ['All', 'male', 'female'],
        help="Filter by passenger gender"
    )
    
    # Embarkation port filter
    embarked_filter = st.sidebar.selectbox(
        "Embarkation Port",
        ['All', 'S', 'C', 'Q'],
        help="Filter by embarkation port (S=Southampton, C=Cherbourg, Q=Queenstown)"
    )
    
    # Survival filter
    survival_filter = st.sidebar.selectbox(
        "Survival Status",
        ['All', 'Survived', 'Died'],
        help="Filter by survival status"
    )
    
    # Age range filter
    age_range = st.sidebar.slider(
        "Age Range",
        min_value=0,
        max_value=80,
        value=(0, 80),
        help="Filter by age range"
    )
    
    return {
        'pclass_filter': pclass_filter,
        'sex_filter': sex_filter,
        'embarked_filter': embarked_filter,
        'survival_filter': survival_filter,
        'age_range': age_range
    }

def main():
    """Main function to run the Streamlit app."""
    
    # Header
    st.title("🚢 Titanic Dataset Explorer")
    st.markdown("### Interactive Analysis of the Famous Titanic Passenger Dataset")
    
    # Introduction
    st.markdown("""
    This dashboard explores the Titanic dataset, providing insights into passenger demographics, 
    survival patterns, and key statistics. Use the filters in the sidebar to explore different 
    subsets of the data and see how the visualizations update accordingly.
    
    **Dataset Context:** The Titanic dataset contains information about passengers aboard the 
    RMS Titanic, including survival status, passenger class, age, gender, fare, and more.
    """)
    
    # Load data
    st.header("📥 Data Loading")
    df = load_titanic_data()
    
    # Preprocess data
    df_processed = preprocess_data(df)
    
    # Display basic info in expandable section
    with st.expander("📋 Dataset Information", expanded=False):
        info = get_basic_info(df_processed)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write(f"**Dataset Shape:** {info['shape'][0]} rows × {info['shape'][1]} columns")
            st.write(f"**Memory Usage:** {info['memory_usage'] / 1024:.2f} KB")
            
            st.write("**Numeric Columns:**")
            for col in info['numeric_columns']:
                st.write(f"  - {col}")
        
        with col2:
            st.write("**Missing Values:**")
            missing_data = info['missing_values'][info['missing_values'] > 0]
            if len(missing_data) > 0:
                for col, count in missing_data.items():
                    st.write(f"  - {col}: {count}")
            else:
                st.write("  - No missing values found")
            
            st.write("**Categorical Columns:**")
            for col in info['categorical_columns']:
                st.write(f"  - {col}")
    
    # Create filters
    filter_params = create_sidebar_filters()
    
    # Apply filters
    filtered_df = apply_filters(df_processed, filter_params)
    
    # Display statistics
    display_statistics(df_processed, filtered_df)
    
    # Visualizations
    st.header("📊 Data Visualizations")
    
    # Chart 1: Survival by Sex
    st.subheader("Chart 1: Survival Rates by Gender")
    st.plotly_chart(plot_survival_by_sex(df_processed), use_container_width=True)
    st.caption("This chart shows the survival rates by gender, with stacked bars representing the number of passengers who survived vs. died for each gender category.")
    
    # Chart 2: Age Distribution
    st.subheader("Chart 2: Age Distribution of Passengers")
    st.plotly_chart(plot_age_distribution(df_processed, filter_params), use_container_width=True)
    st.caption("This histogram displays the age distribution of passengers. When no survival filter is applied, it shows the distribution by survival status with different colors.")
    
    # Chart 3: Correlation Heatmap
    st.subheader("Chart 3: Correlation Heatmap of Numeric Features")
    st.plotly_chart(plot_numeric_correlations(df_processed), use_container_width=True)
    st.caption("This heatmap shows the correlation coefficients between numeric features. Red indicates positive correlation, blue indicates negative correlation, and white indicates no correlation.")
    
    # Filtered data preview
    st.header("🔍 Filtered Data Preview")
    st.write(f"Showing {len(filtered_df)} out of {len(df_processed)} passengers based on selected filters.")
    
    if len(filtered_df) > 0:
        st.dataframe(filtered_df.head(10), use_container_width=True)
    else:
        st.warning("No data matches the selected filters. Try adjusting your filter criteria.")
    
    # Footer with information
    st.markdown("---")
    st.markdown("""
    **How to extend this dashboard:**
    - Add more visualizations (e.g., fare distribution by class, family size analysis)
    - Implement machine learning models for survival prediction
    - Add more interactive features like drill-down capabilities
    - Include data export functionality
    
    **Data source:** [Kaggle Titanic Dataset](https://www.kaggle.com/c/titanic/data)
    """)

if __name__ == "__main__":
    main()
