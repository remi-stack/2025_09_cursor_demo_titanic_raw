"""
Test script for Titanic Streamlit App
=====================================

This script tests the core functionality of the app without requiring
the actual Titanic dataset.
"""

import pandas as pd
import numpy as np
from typing import Dict
import sys
import os

# Add the current directory to Python path to import app functions
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_data_preprocessing():
    """Test the data preprocessing function with mock data."""
    print("🧪 Testing data preprocessing...")
    
    # Create mock Titanic dataset
    mock_data = {
        'PassengerId': range(1, 101),
        'Survived': np.random.choice([0, 1], 100, p=[0.6, 0.4]),
        'Pclass': np.random.choice([1, 2, 3], 100, p=[0.2, 0.3, 0.5]),
        'Name': [f'Passenger {i}' for i in range(1, 101)],
        'Sex': np.random.choice(['male', 'female'], 100, p=[0.65, 0.35]),
        'Age': np.random.normal(30, 15, 100).clip(0, 80),
        'SibSp': np.random.poisson(0.5, 100),
        'Parch': np.random.poisson(0.4, 100),
        'Ticket': [f'Ticket_{i}' for i in range(1, 101)],
        'Fare': np.random.exponential(30, 100),
        'Cabin': [f'Cabin_{i}' if np.random.random() > 0.3 else np.nan for i in range(1, 101)],
        'Embarked': np.random.choice(['S', 'C', 'Q'], 100, p=[0.7, 0.2, 0.1])
    }
    
    mock_df = pd.DataFrame(mock_data)
    
    # Test preprocessing
    try:
        from app import preprocess_data, get_basic_info
        
        # Test preprocessing
        processed_df = preprocess_data(mock_df)
        print("✅ Data preprocessing successful")
        print(f"   Original shape: {mock_df.shape}")
        print(f"   Processed shape: {processed_df.shape}")
        
        # Test basic info
        info = get_basic_info(processed_df)
        print("✅ Basic info extraction successful")
        print(f"   Dataset shape: {info['shape']}")
        print(f"   Memory usage: {info['memory_usage'] / 1024:.2f} KB")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Error during testing: {e}")
        return False

def test_filtering():
    """Test the filtering functionality."""
    print("\n🧪 Testing filtering functionality...")
    
    try:
        from app import apply_filters
        
        # Create mock data
        mock_data = {
            'PassengerId': range(1, 51),
            'Survived': np.random.choice([0, 1], 50),
            'Pclass': np.random.choice([1, 2, 3], 50),
            'Sex': np.random.choice(['male', 'female'], 50),
            'Age': np.random.normal(30, 15, 50).clip(0, 80),
            'Embarked': np.random.choice(['S', 'C', 'Q'], 50)
        }
        
        mock_df = pd.DataFrame(mock_data)
        
        # Test filters
        filter_params = {
            'pclass_filter': '1',
            'sex_filter': 'female',
            'embarked_filter': 'S',
            'survival_filter': 'Survived',
            'age_range': (20, 40)
        }
        
        filtered_df = apply_filters(mock_df, filter_params)
        print("✅ Filtering successful")
        print(f"   Original records: {len(mock_df)}")
        print(f"   Filtered records: {len(filtered_df)}")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Error during filtering test: {e}")
        return False

def test_visualization_functions():
    """Test the visualization functions."""
    print("\n🧪 Testing visualization functions...")
    
    try:
        from app import plot_survival_by_sex, plot_age_distribution, plot_numeric_correlations
        
        # Create mock data
        mock_data = {
            'PassengerId': range(1, 101),
            'Survived': np.random.choice([0, 1], 100, p=[0.6, 0.4]),
            'Pclass': np.random.choice([1, 2, 3], 100),
            'Sex': np.random.choice(['male', 'female'], 100, p=[0.65, 0.35]),
            'Age': np.random.normal(30, 15, 100).clip(0, 80),
            'SibSp': np.random.poisson(0.5, 100),
            'Parch': np.random.poisson(0.4, 100),
            'Fare': np.random.exponential(30, 100),
            'Embarked': np.random.choice(['S', 'C', 'Q'], 100)
        }
        
        mock_df = pd.DataFrame(mock_data)
        
        # Test plotting functions
        fig1 = plot_survival_by_sex(mock_df)
        print("✅ Survival by sex chart created")
        
        filter_params = {'survival_filter': 'All', 'age_range': (0, 80)}
        fig2 = plot_age_distribution(mock_df, filter_params)
        print("✅ Age distribution chart created")
        
        fig3 = plot_numeric_correlations(mock_df)
        print("✅ Correlation heatmap created")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Error during visualization test: {e}")
        return False

def main():
    """Run all tests."""
    print("🚀 Starting Titanic App Tests...\n")
    
    tests = [
        test_data_preprocessing,
        test_filtering,
        test_visualization_functions
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print(f"\n📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! The app is ready to run.")
        print("\nTo run the app:")
        print("1. Download the Titanic dataset from Kaggle")
        print("2. Place it in the same directory as app.py")
        print("3. Run: streamlit run app.py")
    else:
        print("❌ Some tests failed. Please check the errors above.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
