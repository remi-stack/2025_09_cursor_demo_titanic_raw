# 🚢 Titanic Dataset Explorer - Streamlit App

A comprehensive, interactive Streamlit application for exploring and analyzing the famous Titanic dataset from Kaggle.

## 📋 Project Status - Kanban Board

### ✅ **COMPLETED TASKS**

#### **Dataset and Data Loading**
- [x] Load Titanic dataset (full version) from Kaggle using pandas
- [x] Include precise data-loading block with error handling (try/except)
- [x] Brief dataset description in the UI
- [x] Show basic data info (shape, dtypes, missing values) in expandable panel

#### **Scope and Analyses**
- [x] Compute and display key statistics (passenger class, survival rates by gender, age distribution, fare statistics, embarkation port)
- [x] **Chart 1**: Bar chart illustrating survival by sex with survival rate annotations
- [x] **Chart 2**: Histogram of passenger ages with optional binning by survival status
- [x] **Chart 3**: Correlation heatmap focusing on numeric features (age, fare, passengers, survival)
- [x] Include interactive widgets (slider, multiselect, radio) to filter dataset
- [x] All charts update according to filter selections
- [x] Concise table of computed statistics (mean, median, std) for selected features

#### **Interactivity and Layout**
- [x] Visually appealing dashboard with title and subtitle
- [x] Accessible and consistent color palette across charts
- [x] Responsive two-column layout that works in Streamlit
- [x] Clear section headings and tooltips on charts
- [x] Clearly labeled widgets placed for intuitive use
- [x] Short introduction text explaining dataset context

#### **Design and Best Practices**
- [x] Single data-loading function with caching (`@st.cache_data`)
- [x] Separated data preprocessing, visualization, and layout into testable functions
- [x] Comprehensive docstrings and inline comments
- [x] Code style aligns with PEP 8 and includes type hints
- [x] Guidance on testing and validation steps

#### **Output and Deliverables**
- [x] Complete, runnable app script named `app.py`
- [x] Loads Titanic dataset from Kaggle via pandas
- [x] Produces three distinct charts as specified
- [x] Includes interactive filter and up-to-date statistics
- [x] Runs with `streamlit run app.py`
- [x] Inline code comments explaining data transformations
- [x] Brief narrative describing data source and preprocessing steps

---

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Installation

1. **Clone or download this repository**
2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Download the Titanic dataset:**
   - Go to [Kaggle Titanic Dataset](https://www.kaggle.com/c/titanic/data)
   - Download `train.csv`
   - Place it in the same directory as `app.py`
   - Rename it to `titanic.csv` (or update the path in the code)

4. **Run the app:**
   ```bash
   streamlit run app.py
   ```

5. **Open your browser** and navigate to the displayed URL (usually `http://localhost:8501`)

---

## 🎯 Features

### **Interactive Dashboard**
- **Real-time filtering** by passenger class, gender, embarkation port, survival status, and age range
- **Dynamic statistics** that update based on filter selections
- **Responsive layout** that works on different screen sizes

### **Data Visualizations**
1. **Survival by Gender Chart**: Stacked bar chart showing survival rates with percentage annotations
2. **Age Distribution Histogram**: Interactive histogram with survival status overlay
3. **Correlation Heatmap**: Visual representation of relationships between numeric features

### **Data Analysis**
- **Comprehensive statistics** including mean, median, standard deviation
- **Missing value handling** with intelligent imputation strategies
- **Derived features** like family size, passenger titles, and alone status

---

## 🏗️ Architecture

### **Code Structure**
```
app.py
├── Data Loading & Preprocessing
│   ├── load_titanic_data() - Cached data loading with error handling
│   ├── preprocess_data() - Data cleaning and feature engineering
│   └── get_basic_info() - Dataset metadata extraction
├── Visualization Functions
│   ├── plot_survival_by_sex() - Gender-based survival analysis
│   ├── plot_age_distribution() - Age distribution with filters
│   └── plot_numeric_correlations() - Feature correlation heatmap
├── UI Components
│   ├── create_sidebar_filters() - Interactive filter widgets
│   ├── apply_filters() - Data filtering logic
│   └── display_statistics() - Statistics display
└── Main Application
    └── main() - App orchestration and layout
```

### **Key Design Patterns**
- **Separation of Concerns**: Data, visualization, and UI logic are separated
- **Caching**: Data loading is cached for performance
- **Error Handling**: Comprehensive error handling with user-friendly messages
- **Type Hints**: Full type annotations for maintainability
- **Responsive Design**: Layout adapts to different screen sizes

---

## 🔧 Customization

### **Adding New Visualizations**
1. Create a new plotting function following the existing pattern
2. Add the function call in the `main()` function
3. Include appropriate captions and styling

### **Modifying Filters**
1. Update the `create_sidebar_filters()` function
2. Modify the `apply_filters()` function to handle new parameters
3. Ensure all visualizations use the filtered data

### **Changing Color Scheme**
- Modify the `COLORS` dictionary at the top of the file
- Update chart colors in individual plotting functions

---

## 🧪 Testing and Validation

### **Local Testing**
1. **Data Loading**: Verify the app loads the Titanic dataset correctly
2. **Filter Functionality**: Test all filter combinations work as expected
3. **Chart Updates**: Ensure charts respond to filter changes
4. **Responsiveness**: Test on different screen sizes

### **Data Validation**
- **Shape**: Should show 891 rows × 12 columns (standard Titanic dataset)
- **Survival Rate**: Approximately 38.4% (342 out of 891 passengers)
- **Gender Distribution**: Roughly 65% male, 35% female
- **Age Range**: 0.42 to 80 years

---

## 📊 Dataset Information

### **Source**
- **Kaggle Competition**: [Titanic: Machine Learning from Disaster](https://www.kaggle.com/c/titanic)
- **File**: `train.csv` (training dataset)
- **Size**: ~60 KB
- **Records**: 891 passengers

### **Features**
- **Target**: `Survived` (0 = No, 1 = Yes)
- **Categorical**: `Pclass`, `Sex`, `Embarked`, `Cabin`
- **Numeric**: `Age`, `Fare`, `SibSp`, `Parch`
- **Text**: `Name`, `Ticket`

---

## 🚨 Troubleshooting

### **Common Issues**

1. **"Dataset not found" error**
   - Ensure `titanic.csv` is in the same directory as `app.py`
   - Check file permissions and naming

2. **Import errors**
   - Verify all dependencies are installed: `pip install -r requirements.txt`
   - Check Python version compatibility

3. **Charts not displaying**
   - Ensure Plotly is properly installed
   - Check browser console for JavaScript errors

4. **Performance issues**
   - The app uses caching for data loading
   - Large datasets may require additional optimization

---

## 🔮 Future Enhancements

### **Planned Features**
- [ ] Machine learning survival prediction models
- [ ] Additional chart types (scatter plots, box plots)
- [ ] Data export functionality
- [ ] Advanced filtering options
- [ ] Mobile-optimized interface

### **Contributing**
Feel free to submit issues, feature requests, or pull requests to enhance this application.

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

---

## 👥 Credits

- **Dataset**: [Kaggle Titanic Dataset](https://www.kaggle.com/c/titanic/data)
- **Framework**: [Streamlit](https://streamlit.io/)
- **Visualization**: [Plotly](https://plotly.com/), [Matplotlib](https://matplotlib.org/), [Seaborn](https://seaborn.pydata.org/)
- **Data Processing**: [Pandas](https://pandas.pydata.org/), [NumPy](https://numpy.org/)

---

**🎉 All requirements have been successfully implemented! The app is ready to run with `streamlit run app.py`.**
