# Live Emoji Poll App

A minimal, self-contained live poll application built with React frontend and FastAPI backend. Features real-time voting with emoji options and instant visual feedback.

## Features

- **4 Emoji Options**: 👍 ❤️ 😂 🤯
- **Real-time Updates**: Vote counts update instantly on the frontend
- **Visual Results**: Horizontal bar chart showing proportional vote counts
- **Optimistic UI**: Immediate visual feedback with server reconciliation
- **Reset Functionality**: Clear all votes (development feature)
- **Responsive Design**: Works on desktop and mobile devices
- **Accessibility**: ARIA labels and keyboard navigation support

## Project Structure

```
emoji-poll-app/
├── backend/
│   ├── main.py              # FastAPI application
│   └── requirements.txt     # Python dependencies
├── frontend/
│   ├── public/
│   │   └── index.html      # HTML template
│   ├── src/
│   │   ├── App.jsx         # Main React component
│   │   └── index.js        # React entry point
│   └── package.json        # Node.js dependencies
└── README.md               # This file
```

## API Endpoints

### Backend (FastAPI)

- **GET /api/poll** - Get current vote counts
- **POST /api/poll/vote** - Submit a vote for an option
- **POST /api/poll/reset** - Reset all counts to zero

### Data Model

```json
{
  "count": {
    "thumbs_up": 0,
    "heart": 0,
    "laugh": 0,
    "exploding_head": 0
  }
}
```

## Setup & Installation

### Prerequisites

- Python 3.8+ with pip
- Node.js 16+ with npm
- Modern web browser

### Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Start the FastAPI server:
   ```bash
   uvicorn main:app --reload --port 8000
   ```

   The backend will be available at `http://localhost:8000`

### Frontend Setup

1. Open a new terminal and navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install Node.js dependencies:
   ```bash
   npm install
   ```

3. Start the React development server:
   ```bash
   npm start
   ```

   The frontend will automatically open at `http://localhost:3000`

## Usage

1. **Voting**: Click on any emoji button to cast a vote
2. **Real-time Updates**: See vote counts update instantly
3. **Visual Results**: View proportional bar charts below the voting buttons
4. **Reset**: Use the reset button to clear all votes (development feature)

## Development Features

- **Hot Reload**: Both frontend and backend support hot reloading
- **CORS**: Backend configured to allow requests from `localhost:3000`
- **Error Handling**: Comprehensive error handling with user-friendly messages
- **Optimistic Updates**: Immediate UI feedback with server reconciliation

## API Examples

### Get Current Poll Data
```bash
curl http://localhost:8000/api/poll
```

### Submit a Vote
```bash
curl -X POST http://localhost:8000/api/poll/vote \
  -H "Content-Type: application/json" \
  -d '{"option": "heart"}'
```

### Reset Poll
```bash
curl -X POST http://localhost:8000/api/poll/reset
```

## Technical Details

- **Frontend**: React 18 with hooks, CSS-in-JS styling
- **Backend**: FastAPI with Pydantic models
- **State Management**: React useState for local state
- **Data Persistence**: In-memory storage (resets on server restart)
- **Real-time Feel**: Optimistic updates with server reconciliation
- **Responsive Design**: Flexbox layout with mobile-friendly sizing

## Troubleshooting

### Common Issues

1. **Port Already in Use**: If port 8000 or 3000 is busy, change the port in the respective startup commands
2. **CORS Errors**: Ensure the backend is running on port 8000 and frontend on port 3000
3. **Dependencies**: Make sure all Python and Node.js dependencies are properly installed

### Reset Issues

- The reset functionality is intended for development use
- Counts reset to zero when the backend server restarts
- For production use, consider implementing persistent storage

## License

This project is open source and available under the MIT License.
