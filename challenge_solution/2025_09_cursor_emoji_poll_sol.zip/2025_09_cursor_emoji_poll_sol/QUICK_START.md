# Quick Start Guide

Get your Live Emoji Poll app running in under 5 minutes!

## Prerequisites Check

Make sure you have:
- ✅ Python 3.8+ installed (`python --version`)
- ✅ Node.js 16+ installed (`node --version`)
- ✅ pip installed (`pip --version`)
- ✅ npm installed (`npm --version`)

## Step 1: Install Backend Dependencies

```bash
cd backend
pip install -r requirements.txt
```

## Step 2: Install Frontend Dependencies

```bash
cd frontend
npm install
```

## Step 3: Start Backend Server

**Option A: Command Line**
```bash
cd backend
uvicorn main:app --reload --port 8000
```

**Option B: Windows Batch File**
Double-click `start_backend.bat`

## Step 4: Start Frontend (New Terminal)

**Option A: Command Line**
```bash
cd frontend
npm start
```

**Option B: Windows Batch File**
Double-click `start_frontend.bat`

## Step 5: Open Your Browser

The app will automatically open at `http://localhost:3000`

## What You'll See

- 🎯 **4 Emoji Voting Buttons**: 👍 ❤️ 😂 🤯
- 📊 **Live Results**: Bar charts that update in real-time
- 🔄 **Reset Button**: Clear all votes (development feature)

## Test the App

1. Click any emoji button to vote
2. Watch the bar chart update instantly
3. Open multiple browser tabs to see real-time updates
4. Use the reset button to start fresh

## Troubleshooting

- **Backend won't start**: Check if port 8000 is free
- **Frontend won't start**: Check if port 3000 is free
- **CORS errors**: Ensure backend is running on port 8000
- **Dependencies issues**: Re-run pip install and npm install

## API Testing

Test the backend directly:
```bash
curl http://localhost:8000/api/poll
```

## Next Steps

- Customize emoji options in `backend/main.py`
- Modify styling in `frontend/src/App.jsx`
- Add persistent storage for production use
- Deploy to your preferred hosting platform

## Support

Check the main `README.md` for detailed documentation and API reference.
