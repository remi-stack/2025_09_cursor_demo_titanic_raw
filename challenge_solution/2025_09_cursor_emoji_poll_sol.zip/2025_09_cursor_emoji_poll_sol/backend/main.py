from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# In-memory counts
counts = {
    "thumbs_up": 0,
    "heart": 0,
    "laugh": 0,
    "exploding_head": 0
}

origins = ["http://localhost:3000"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class Vote(BaseModel):
    option: str

@app.get("/api/poll")
def get_poll():
    return {"count": counts}

@app.post("/api/poll/vote")
def vote(v: Vote):
    if v.option not in counts:
        raise HTTPException(status_code=400, detail="Invalid option")
    counts[v.option] += 1
    return {"success": True, "count": counts}

@app.post("/api/poll/reset")
def reset_poll():
    global counts
    counts = {key: 0 for key in counts}
    return {"success": True, "count": counts}
