import React, { useEffect, useState } from "react";

const EMOJI_MAP = {
  thumbs_up: "👍",
  heart: "❤️",
  laugh: "😂",
  exploding_head: "🤯"
};

const OPTIONS = Object.keys(EMOJI_MAP);

function App() {
  const [counts, setCounts] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchInitialCounts();
  }, []);

  const fetchInitialCounts = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/poll");
      if (response.ok) {
        const data = await response.json();
        setCounts(data.count);
        setError(null);
      } else {
        throw new Error("Failed to fetch poll data");
      }
    } catch (err) {
      setError("Failed to load poll data");
      console.error("Error fetching poll:", err);
    } finally {
      setLoading(false);
    }
  };

  const vote = async (option) => {
    if (!counts) return;
    
    // Optimistic update
    const optimisticCounts = { ...counts, [option]: counts[option] + 1 };
    setCounts(optimisticCounts);
    
    try {
      const response = await fetch("/api/poll/vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ option })
      });
      
      if (response.ok) {
        const data = await response.json();
        // Use server response to ensure accuracy
        setCounts(data.count);
      } else {
        // Rollback on error
        setCounts(counts);
        setError("Failed to submit vote");
      }
    } catch (err) {
      // Rollback on error
      setCounts(counts);
      setError("Failed to submit vote");
      console.error("Error voting:", err);
    }
  };

  const resetPoll = async () => {
    try {
      const response = await fetch("/api/poll/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      
      if (response.ok) {
        const data = await response.json();
        setCounts(data.count);
        setError(null);
      } else {
        setError("Failed to reset poll");
      }
    } catch (err) {
      setError("Failed to reset poll");
      console.error("Error resetting poll:", err);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: 20, textAlign: "center" }}>
        <div>Loading poll data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ padding: 20, textAlign: "center" }}>
        <div style={{ color: "red", marginBottom: 16 }}>{error}</div>
        <button onClick={fetchInitialCounts}>Retry</button>
      </div>
    );
  }

  if (!counts) {
    return (
      <div style={{ padding: 20, textAlign: "center" }}>
        <div>No poll data available</div>
        <button onClick={fetchInitialCounts}>Refresh</button>
      </div>
    );
  }

  const maxCount = Math.max(...Object.values(counts), 1);

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: "0 auto" }}>
      <h1 style={{ textAlign: "center", marginBottom: 32 }}>Live Emoji Poll</h1>
      
      {/* Voting Buttons */}
      <div style={{ 
        display: "flex", 
        gap: 12, 
        marginBottom: 32, 
        justifyContent: "center",
        flexWrap: "wrap"
      }}>
        {OPTIONS.map((option) => (
          <button
            key={option}
            onClick={() => vote(option)}
            aria-label={`Vote for ${option}`}
            style={{
              padding: "12px 20px",
              fontSize: "18px",
              border: "2px solid #e5e7eb",
              borderRadius: "8px",
              background: "white",
              cursor: "pointer",
              transition: "all 0.2s",
              minWidth: "80px"
            }}
            onMouseEnter={(e) => {
              e.target.style.borderColor = "#3b82f6";
              e.target.style.transform = "translateY(-2px)";
            }}
            onMouseLeave={(e) => {
              e.target.style.borderColor = "#e5e7eb";
              e.target.style.transform = "translateY(0)";
            }}
          >
            <div style={{ fontSize: "24px", marginBottom: "4px" }}>
              {EMOJI_MAP[option]}
            </div>
            <div style={{ fontSize: "12px", textTransform: "capitalize" }}>
              {option.replace("_", " ")}
            </div>
          </button>
        ))}
      </div>

      {/* Results Bar Chart */}
      <div aria-label="poll-results" style={{ marginBottom: 32 }}>
        <h3 style={{ textAlign: "center", marginBottom: 20 }}>Results</h3>
        {OPTIONS.map((option) => {
          const count = counts[option] || 0;
          const width = (count / maxCount) * 100;
          return (
            <div key={option} style={{ 
              display: "flex", 
              alignItems: "center", 
              marginBottom: 16,
              gap: 12
            }}>
              <span style={{ 
                width: 40, 
                fontSize: "20px", 
                textAlign: "center" 
              }}>
                {EMOJI_MAP[option]}
              </span>
              <div style={{ 
                flex: 1,
                height: 20, 
                background: "#f3f4f6", 
                borderRadius: "10px",
                position: "relative",
                overflow: "hidden"
              }}>
                <div style={{
                  width: `${width}%`,
                  height: "100%",
                  background: "linear-gradient(90deg, #3b82f6, #1d4ed8)",
                  borderRadius: "10px",
                  transition: "width 0.3s ease",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
                }} />
              </div>
              <span style={{ 
                width: 50, 
                textAlign: "right", 
                fontWeight: "bold",
                fontSize: "16px"
              }}>
                {count}
              </span>
            </div>
          );
        })}
      </div>

      {/* Action Buttons */}
      <div style={{ textAlign: "center", marginBottom: 16 }}>
        <p style={{ fontSize: "14px", color: "#6b7280", marginBottom: 16 }}>
          💡 <strong>Developer Tools:</strong> Explore the API documentation and test endpoints
        </p>
      </div>
      <div style={{ textAlign: "center", display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
        {/* Reset Button */}
        <button
          onClick={resetPoll}
          aria-label="Reset poll counts"
          style={{
            padding: "10px 20px",
            fontSize: "14px",
            border: "1px solid #dc2626",
            borderRadius: "6px",
            background: "white",
            color: "#dc2626",
            cursor: "pointer",
            transition: "all 0.2s"
          }}
          onMouseEnter={(e) => {
            e.target.style.background = "#dc2626";
            e.target.style.color = "white";
          }}
          onMouseLeave={(e) => {
            e.target.style.background = "white";
            e.target.style.color = "#dc2626";
          }}
        >
          Reset Poll
        </button>

        {/* API Documentation Button */}
        <button
          onClick={() => window.open('http://localhost:8000/docs', '_blank')}
          aria-label="Open API documentation"
          style={{
            padding: "10px 20px",
            fontSize: "14px",
            border: "1px solid #3b82f6",
            borderRadius: "6px",
            background: "white",
            color: "#3b82f6",
            cursor: "pointer",
            transition: "all 0.2s"
          }}
          onMouseEnter={(e) => {
            e.target.style.background = "#3b82f6";
            e.target.style.color = "white";
          }}
          onMouseLeave={(e) => {
            e.target.style.background = "white";
            e.target.style.color = "#3b82f6";
          }}
        >
          📚 API Docs
        </button>

        {/* Raw API Button */}
        <button
          onClick={() => window.open('http://localhost:8000/api/poll', '_blank')}
          aria-label="Open raw API endpoint"
          style={{
            padding: "10px 20px",
            fontSize: "14px",
            border: "1px solid #10b981",
            borderRadius: "6px",
            background: "white",
            color: "#10b981",
            cursor: "pointer",
            transition: "all 0.2s"
          }}
          onMouseEnter={(e) => {
            e.target.style.background = "#10b981";
            e.target.style.color = "white";
          }}
          onMouseLeave={(e) => {
            e.target.style.background = "white";
            e.target.style.color = "#10b981";
          }}
        >
          🔗 Raw API
        </button>
      </div>
    </div>
  );
}

export default App;
